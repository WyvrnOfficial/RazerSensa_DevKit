==============================Mod Ray Shooter===============================
Version: v1.0 Beta
Date:20/12/2023
Company: InterHaptics - Waiting4Studio
Author: Chenshuo.L - Alexander.M - Thomas.B
Description: RayShooter mod for InterHaptics- easy version

Updated:
