Antoine Mariton - 21/05/2024 - v1.0.1.0

1/ execute Install_RzInterHaptics_Inbox_1.0.4.1.exe to instal the latest communication dll for sensa device.

2/ open Synesthesia.exe (the build you want) as administrator.

3/ use the fake client to send message if needed.

Sensa builds will only works if the latest dll is installed.


You can kill the synesthesia program using the killer one.

To generate an haptic folder, press "1", open your game, trigger all chroma animation, then press "2"



